﻿Option Strict On
Option Explicit On

<Microsoft.VisualStudio.Tools.Applications.Runtime.StartupObjectAttribute(0), _
 Global.System.Security.Permissions.PermissionSetAttribute(Global.System.Security.Permissions.SecurityAction.Demand, Name:="FullTrust"), _
 Global.System.Runtime.InteropServices.ComVisibleAttribute(False)> _
Partial Public NotInheritable Class ThisAddIn
    Inherits Microsoft.Office.Tools.Outlook.OutlookAddInBase

    Friend WithEvents CustomTaskPanes As Microsoft.Office.Tools.CustomTaskPaneCollection

    <Global.System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.VisualStudio.Tools.Office.ProgrammingModel.dll", "11.0.0.0")> _
    Friend WithEvents Application As Microsoft.Office.Interop.Outlook.Application

    <Global.System.Diagnostics.DebuggerNonUserCodeAttribute(), _
     Global.System.ComponentModel.EditorBrowsableAttribute(Global.System.ComponentModel.EditorBrowsableState.Never)> _
    Public Sub New(ByVal factory As Global.Microsoft.Office.Tools.Outlook.Factory, ByVal serviceProvider As Global.System.IServiceProvider)
        MyBase.New(factory, serviceProvider, "AddIn", "ThisAddIn")
        Globals.Factory = factory
    End Sub

    <Global.System.Diagnostics.DebuggerNonUserCodeAttribute(), _
     Global.System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.VisualStudio.Tools.Office.ProgrammingModel.dll", "11.0.0.0"), _
     Global.System.ComponentModel.EditorBrowsableAttribute(Global.System.ComponentModel.EditorBrowsableState.Never)> _
    Protected Overrides Sub Initialize()
        MyBase.Initialize()
        Me.Application = Me.GetHostItem(Of Microsoft.Office.Interop.Outlook.Application)(GetType(Microsoft.Office.Interop.Outlook.Application), "Application")
        Globals.ThisAddIn = Me
        Global.System.Windows.Forms.Application.EnableVisualStyles()
        Me.InitializeCachedData()
        Me.InitializeControls()
        Me.InitializeComponents()
        Me.InitializeData()
    End Sub

    <Global.System.Diagnostics.DebuggerNonUserCodeAttribute(), _
     Global.System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.VisualStudio.Tools.Office.ProgrammingModel.dll", "11.0.0.0"), _
     Global.System.ComponentModel.EditorBrowsableAttribute(Global.System.ComponentModel.EditorBrowsableState.Never)> _
    Protected Overrides Sub FinishInitialization()
        Me.OnStartup()
    End Sub

    <Global.System.Diagnostics.DebuggerNonUserCodeAttribute(), _
     Global.System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.VisualStudio.Tools.Office.ProgrammingModel.dll", "11.0.0.0"), _
     Global.System.ComponentModel.EditorBrowsableAttribute(Global.System.ComponentModel.EditorBrowsableState.Never)> _
    Protected Overrides Sub InitializeDataBindings()
        Me.BeginInitialization()
        Me.BindToData()
        Me.EndInitialization()
    End Sub

    <Global.System.Diagnostics.DebuggerNonUserCodeAttribute(), _
     Global.System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.VisualStudio.Tools.Office.ProgrammingModel.dll", "11.0.0.0"), _
     Global.System.ComponentModel.EditorBrowsableAttribute(Global.System.ComponentModel.EditorBrowsableState.Never)> _
    Private Sub InitializeCachedData()
        If Me.DataHost Is Nothing Then
            Return
        End If
        If Me.DataHost.IsCacheInitialized Then
            Me.DataHost.FillCachedData(Me)
        End If
    End Sub

    <Global.System.Diagnostics.DebuggerNonUserCodeAttribute(), _
     Global.System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.VisualStudio.Tools.Office.ProgrammingModel.dll", "11.0.0.0"), _
     Global.System.ComponentModel.EditorBrowsableAttribute(Global.System.ComponentModel.EditorBrowsableState.Never)> _
    Private Sub InitializeData()
    End Sub

    <Global.System.Diagnostics.DebuggerNonUserCodeAttribute(), _
     Global.System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.VisualStudio.Tools.Office.ProgrammingModel.dll", "11.0.0.0"), _
     Global.System.ComponentModel.EditorBrowsableAttribute(Global.System.ComponentModel.EditorBrowsableState.Never)> _
    Private Sub BindToData()
    End Sub

    <Global.System.Diagnostics.DebuggerNonUserCodeAttribute(), _
     Global.System.ComponentModel.EditorBrowsableAttribute(Global.System.ComponentModel.EditorBrowsableState.Advanced)> _
    Private Sub StartCaching(ByVal MemberName As String)
        Me.DataHost.StartCaching(Me, MemberName)
    End Sub

    <Global.System.Diagnostics.DebuggerNonUserCodeAttribute(), _
     Global.System.ComponentModel.EditorBrowsableAttribute(Global.System.ComponentModel.EditorBrowsableState.Advanced)> _
    Private Sub StopCaching(ByVal MemberName As String)
        Me.DataHost.StopCaching(Me, MemberName)
    End Sub

    <Global.System.Diagnostics.DebuggerNonUserCodeAttribute(), _
     Global.System.ComponentModel.EditorBrowsableAttribute(Global.System.ComponentModel.EditorBrowsableState.Advanced)> _
    Private Function IsCached(ByVal MemberName As String) As Boolean
        Return Me.DataHost.IsCached(Me, MemberName)
    End Function

    <Global.System.Diagnostics.DebuggerNonUserCodeAttribute(), _
     Global.System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.VisualStudio.Tools.Office.ProgrammingModel.dll", "11.0.0.0"), _
     Global.System.ComponentModel.EditorBrowsableAttribute(Global.System.ComponentModel.EditorBrowsableState.Never)> _
    Private Sub BeginInitialization()
        Me.BeginInit()
        Me.CustomTaskPanes.BeginInit()
    End Sub

    <Global.System.Diagnostics.DebuggerNonUserCodeAttribute(), _
     Global.System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.VisualStudio.Tools.Office.ProgrammingModel.dll", "11.0.0.0"), _
     Global.System.ComponentModel.EditorBrowsableAttribute(Global.System.ComponentModel.EditorBrowsableState.Never)> _
    Private Sub EndInitialization()
        Me.CustomTaskPanes.EndInit()
        Me.EndInit()
    End Sub

    <Global.System.Diagnostics.DebuggerNonUserCodeAttribute(), _
     Global.System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.VisualStudio.Tools.Office.ProgrammingModel.dll", "11.0.0.0"), _
     Global.System.ComponentModel.EditorBrowsableAttribute(Global.System.ComponentModel.EditorBrowsableState.Never)> _
    Private Sub InitializeControls()
        Me.CustomTaskPanes = Globals.Factory.CreateCustomTaskPaneCollection(Nothing, Nothing, "CustomTaskPanes", "CustomTaskPanes", Me)
    End Sub

    <Global.System.Diagnostics.DebuggerNonUserCodeAttribute(), _
     Global.System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.VisualStudio.Tools.Office.ProgrammingModel.dll", "11.0.0.0"), _
     Global.System.ComponentModel.EditorBrowsableAttribute(Global.System.ComponentModel.EditorBrowsableState.Never)> _
    Private Sub InitializeComponents()
    End Sub

    <Global.System.Diagnostics.DebuggerNonUserCodeAttribute(), _
     Global.System.ComponentModel.EditorBrowsableAttribute(Global.System.ComponentModel.EditorBrowsableState.Advanced)> _
    Private Function NeedsFill(ByVal MemberName As String) As Boolean
        Return Me.DataHost.NeedsFill(Me, MemberName)
    End Function

    <Global.System.Diagnostics.DebuggerNonUserCodeAttribute(), _
     Global.System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.VisualStudio.Tools.Office.ProgrammingModel.dll", "11.0.0.0"), _
     Global.System.ComponentModel.EditorBrowsableAttribute(Global.System.ComponentModel.EditorBrowsableState.Never)> _
    Protected Overrides Sub OnShutdown()
        Me.CustomTaskPanes.Dispose()
        MyBase.OnShutdown()
    End Sub
End Class

<Global.System.Diagnostics.DebuggerNonUserCodeAttribute(), _
 Global.System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.VisualStudio.Tools.Office.ProgrammingModel.dll", "11.0.0.0")> _
Partial Friend NotInheritable Class Globals

    Private Sub New()
        MyBase.New()
    End Sub

    Private Shared _ThisAddIn As ThisAddIn

    Private Shared _factory As Global.Microsoft.Office.Tools.Outlook.Factory

    Private Shared _ThisRibbonCollection As ThisRibbonCollection

    Private Shared _ThisFormRegionCollection As ThisFormRegionCollection

    Friend Shared Property ThisAddIn() As ThisAddIn
        Get
            Return _ThisAddIn
        End Get
        Set(value As ThisAddIn)
            If (_ThisAddIn Is Nothing) Then
                _ThisAddIn = value
            Else
                Throw New System.NotSupportedException()
            End If
        End Set
    End Property

    Friend Shared Property Factory() As Global.Microsoft.Office.Tools.Outlook.Factory
        Get
            Return _factory
        End Get
        Set(value As Global.Microsoft.Office.Tools.Outlook.Factory)
            If (_factory Is Nothing) Then
                _factory = value
            Else
                Throw New System.NotSupportedException()
            End If
        End Set
    End Property

    Friend Shared ReadOnly Property Ribbons() As ThisRibbonCollection
        Get
            If (_ThisRibbonCollection Is Nothing) Then
                _ThisRibbonCollection = New ThisRibbonCollection(_factory.GetRibbonFactory)
            End If
            Return _ThisRibbonCollection
        End Get
    End Property

    Friend Shared ReadOnly Property FormRegions() As ThisFormRegionCollection
        Get
            If (_ThisFormRegionCollection Is Nothing) Then
                _ThisFormRegionCollection = New ThisFormRegionCollection(Globals.ThisAddIn.GetFormRegions)
            End If
            Return _ThisFormRegionCollection
        End Get
    End Property
End Class

'''
<Global.System.Diagnostics.DebuggerNonUserCodeAttribute(), _
 Global.System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.VisualStudio.Tools.Office.ProgrammingModel.dll", "11.0.0.0")> _
Partial Friend NotInheritable Class ThisRibbonCollection
    Inherits Microsoft.Office.Tools.Ribbon.RibbonCollectionBase

    '''
    Friend Sub New(ByVal factory As Global.Microsoft.Office.Tools.Ribbon.RibbonFactory)
        MyBase.New(factory)
    End Sub

    Default Friend Overloads ReadOnly Property Item(ByVal inspector As Microsoft.Office.Interop.Outlook.Inspector) As ThisRibbonCollection
        Get
            Return Me.GetRibbonContextCollection(Of ThisRibbonCollection)(inspector)
        End Get
    End Property

    Default Friend Overloads ReadOnly Property Item(ByVal explorer As Microsoft.Office.Interop.Outlook.Explorer) As ThisRibbonCollection
        Get
            Return Me.GetRibbonContextCollection(Of ThisRibbonCollection)(explorer)
        End Get
    End Property
End Class

'''
<Global.System.Diagnostics.DebuggerNonUserCodeAttribute()> _
Partial Friend NotInheritable Class ThisFormRegionCollection
    Inherits Microsoft.Office.Tools.Outlook.FormRegionCollectionBase

    '''
    Public Sub New(ByVal list As System.Collections.Generic.IList(Of Microsoft.Office.Tools.Outlook.IFormRegion))
        MyBase.New(list)
    End Sub

    Default Friend Overloads ReadOnly Property Item(ByVal explorer As Microsoft.Office.Interop.Outlook.Explorer) As WindowFormRegionCollection
        Get
            Return CType(Globals.ThisAddIn.GetFormRegions(explorer, GetType(WindowFormRegionCollection)), WindowFormRegionCollection)
        End Get
    End Property

    Default Friend Overloads ReadOnly Property Item(ByVal inspector As Microsoft.Office.Interop.Outlook.Inspector) As WindowFormRegionCollection
        Get
            Return CType(Globals.ThisAddIn.GetFormRegions(inspector, GetType(WindowFormRegionCollection)), WindowFormRegionCollection)
        End Get
    End Property
End Class

'''
<Global.System.Diagnostics.DebuggerNonUserCodeAttribute()> _
Partial Friend NotInheritable Class WindowFormRegionCollection
    Inherits Microsoft.Office.Tools.Outlook.FormRegionCollectionBase

    '''
    Public Sub New(ByVal list As System.Collections.Generic.IList(Of Microsoft.Office.Tools.Outlook.IFormRegion))
        MyBase.New(list)
    End Sub
End Class
