﻿Imports System.Resources

Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices
Imports System.Security

' Allgemeine Informationen über eine Assembly werden über die folgenden 
' Attribute gesteuert. Ändern Sie diese Attributwerte, um die Informationen zu ändern,
' die mit einer Assembly verknüpft sind.

' Die Werte der Assemblyattribute überprüfen

<Assembly: AssemblyTitle("Fritz!Box Telefon-dingsbums")> 
<Assembly: AssemblyDescription("")> 
<Assembly: AssemblyCompany("Fritz!Box Telefon-Dingsbums")> 
<Assembly: AssemblyProduct("Fritz!Box Telefon-dingsbums")> 
<Assembly: AssemblyCopyright("")> 
<Assembly: AssemblyTrademark("")> 

' Durch Festlegen von ComVisible auf "false" werden die Typen in dieser Assembly unsichtbar 
' für COM-Komponenten. Wenn Sie auf einen Typ in dieser Assembly von 
' COM zugreifen müssen, legen Sie das ComVisible-Attribut für diesen Typ auf "true" fest.
<Assembly: ComVisible(False)> 

'Die folgende GUID bestimmt die ID der Typbibliothek, wenn dieses Projekt für COM verfügbar gemacht wird
<Assembly: Guid("411894A1-05D5-4F89-B336-4A4175D5E537")> 

' Versionsinformationen für eine Assembly bestehen aus den folgenden vier Werten:
'
'      Hauptversion
'      Nebenversion 
'      Buildnummer
'      Revision
'
' Sie können alle Werte angeben oder die standardmäßigen Build- und Revisionsnummern 
' übernehmen, indem Sie "*" eingeben:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("3.7.12.0")> 
<Assembly: AssemblyFileVersion("3.7.12.0")> 
<Assembly: NeutralResourcesLanguageAttribute("de-DE")> 